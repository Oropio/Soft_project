


public interface Shape {
    public void draw();
    public boolean isInHitBox(double isX, double isY);
    public void move(double deltaX, double deltaY);
}
